<?php 

$lang["datepicker_all_time"] = "Todos";
$lang["datepicker_apply"] = "Aplicar";
$lang["datepicker_cancel"] = "Cancelar";
$lang["datepicker_custom"] = "Personalizar";
$lang["datepicker_from"] = "Desde";
$lang["datepicker_last_30"] = "Últimos 30 Días";
$lang["datepicker_last_7"] = "Últimos 7 Días";
$lang["datepicker_last_financial_year"] = "Último año fiscal";
$lang["datepicker_last_month"] = "Mes Anterior";
$lang["datepicker_last_year"] = "Año Anterior";
$lang["datepicker_same_month_last_year"] = "Este Mes hace un año";
$lang["datepicker_same_month_to_same_day_last_year"] = "Este mes hasta hoy, del año pasado";
$lang["datepicker_this_financial_year"] = "Este año fiscal";
$lang["datepicker_this_month"] = "Este Mes";
$lang["datepicker_this_year"] = "Este Año";
$lang["datepicker_to"] = "Hasta";
$lang["datepicker_today"] = "Hoy";
$lang["datepicker_today_last_year"] = "Hoy el año pasado";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Ayer";
