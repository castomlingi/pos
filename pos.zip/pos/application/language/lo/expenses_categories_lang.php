<?php 

$lang["category_name_required"] = "ຊື່ປະເພດຄ່າໃຊ້ຈ່າຍຈຳເປັນຕ້ອງໃສ່";
$lang["expenses_categories_add_item"] = "ເພີ່ມປະເພດ";
$lang["expenses_categories_cannot_be_deleted"] = "ບໍ່ສາມາດລຶບປະເພດຄ່າໃຊ້ຈ່າຍໄດ້";
$lang["expenses_categories_category_id"] = "Id";
$lang["expenses_categories_confirm_delete"] = "ທ່ານຕ້ອງການລຶບປະເພດຄ່າໃຊ້ຈ່າຍທີ່ທ່ານເລືອກແທ້ບໍ່ ?";
$lang["expenses_categories_description"] = "ຄຳອະທິບາຍປະເພດ";
$lang["expenses_categories_error_adding_updating"] = "ຜິດພາດ ການເພີ່ມ/ການແກ້ໄຂ ປະເພດຄ່າໃຊ້ຈ່າຍ";
$lang["expenses_categories_info"] = "ຂໍ້ມູນປະເພດຄ່າໃຊ້ຈ່າຍ";
$lang["expenses_categories_name"] = "ຊື່ປະເພດ";
$lang["expenses_categories_new"] = "ປະເພດໃໝ່";
$lang["expenses_categories_no_expenses_categories_to_display"] = "ບໍ່ມີປະເພດທີ່ຈະສະແດງ";
$lang["expenses_categories_none_selected"] = "ທ່ານຍັງບໍ່ໄດ້ເລືອກປະເພດຄ່າໃຊ້ຈ່າຍໃດເລີຍ";
$lang["expenses_categories_one_or_multiple"] = "ປະເພດຄ່າໃຊ້ຈ່າຍ";
$lang["expenses_categories_quantity"] = "ຈຳນວນ";
$lang["expenses_categories_successful_adding"] = "ເພີ່ມປະເພດຄ່າໃຊ້ຈ່າຍສຳເລັດ";
$lang["expenses_categories_successful_deleted"] = "ລຶບປະເພດຄ່າໃຊ້ຈ່າຍສຳເລັດ";
$lang["expenses_categories_successful_updating"] = "ແກ້ໄຂປະເພດຄ່າໃຊ້ຈ່າຍສຳເລັດ";
$lang["expenses_categories_update"] = "ແກ້ໄຂປະເພດ";
