<?php 

$lang["suppliers_account_number"] = "Kontonummer";
$lang["suppliers_agency_name"] = "Byråns namn";
$lang["suppliers_cannot_be_deleted"] = "Kunde inte radera valda leverantör (er). En eller flera har försäljning.";
$lang["suppliers_company_name"] = "Företagsnamn";
$lang["suppliers_company_name_required"] = "Företagsnamn är ett obligatoriskt fält.";
$lang["suppliers_confirm_delete"] = "Är du säker på att du vill radera den valda Leverantören?";
$lang["suppliers_confirm_restore"] = "Är du säker på att du vill radera den valda Leverantören?";
$lang["suppliers_error_adding_updating"] = "Leverantörsuppdatering eller tillägg misslyckades.";
$lang["suppliers_new"] = "Ny Leverantör";
$lang["suppliers_none_selected"] = "Du har inte valt leverantör (er) att radera.";
$lang["suppliers_one_or_multiple"] = "Leverantörer";
$lang["suppliers_successful_adding"] = "Du har lagt till Leverantör";
$lang["suppliers_successful_deleted"] = "Du har lagt till leverantör";
$lang["suppliers_successful_updating"] = "Du har lagt till leverantör";
$lang["suppliers_supplier"] = "Leverantör";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_update"] = "Uppdatera leverantör";
