<?php 

$lang["tables_all"] = "Alle";
$lang["tables_columns"] = "Kolommen";
$lang["tables_hide_show_pagination"] = "Toon %s record(s)";
$lang["tables_loading"] = "Laden, even geduld...";
$lang["tables_page_from_to"] = "Toon {0}  tot {1} van {2} record(s)";
$lang["tables_refresh"] = "Vernieuwen";
$lang["tables_rows_per_page"] = "{0} records per pagina";
$lang["tables_toggle"] = "Omschakelen";
