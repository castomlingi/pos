<?php 

$lang["category_name_required"] = "De naam van dit veld is verplicht";
$lang["expenses_categories_add_item"] = "Voeg categorie toe";
$lang["expenses_categories_cannot_be_deleted"] = "Kan de categorie niet verwijderen";
$lang["expenses_categories_category_id"] = "Id";
$lang["expenses_categories_confirm_delete"] = "Bent u zeker dat u de geselecteerde uitgave categorie wil verwijderen?";
$lang["expenses_categories_description"] = "";
$lang["expenses_categories_error_adding_updating"] = "";
$lang["expenses_categories_info"] = "";
$lang["expenses_categories_name"] = "";
$lang["expenses_categories_new"] = "";
$lang["expenses_categories_no_expenses_categories_to_display"] = "";
$lang["expenses_categories_none_selected"] = "";
$lang["expenses_categories_one_or_multiple"] = "";
$lang["expenses_categories_quantity"] = "";
$lang["expenses_categories_successful_adding"] = "";
$lang["expenses_categories_successful_deleted"] = "";
$lang["expenses_categories_successful_updating"] = "";
$lang["expenses_categories_update"] = "";
