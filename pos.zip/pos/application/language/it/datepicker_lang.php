<?php 

$lang["datepicker_all_time"] = "Periodo completo";
$lang["datepicker_apply"] = "Applica";
$lang["datepicker_cancel"] = "Cancella";
$lang["datepicker_custom"] = "Personalizzato";
$lang["datepicker_from"] = "Da";
$lang["datepicker_last_30"] = "Ultimi 30 giorni";
$lang["datepicker_last_7"] = "Ultimi 7 giorni";
$lang["datepicker_last_financial_year"] = "Ultimo Anno Fiscale";
$lang["datepicker_last_month"] = "Ultimo Mese";
$lang["datepicker_last_year"] = "Ultimo Anno";
$lang["datepicker_same_month_last_year"] = "Stesso Mese Ultimo Anno";
$lang["datepicker_same_month_to_same_day_last_year"] = "Stesso mese e giorno dell'ultimo Anno";
$lang["datepicker_this_financial_year"] = "Anno Fiscale Corrente";
$lang["datepicker_this_month"] = "Mese Corrente";
$lang["datepicker_this_year"] = "Anno Corrente";
$lang["datepicker_to"] = "To";
$lang["datepicker_today"] = "Oggi";
$lang["datepicker_today_last_year"] = "Oggi Ultimo Anno";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Ieri";
