<?php 

$lang["messages_first_name"] = "នាមត្រកូល";
$lang["messages_last_name"] = "ឈ្មោះ";
$lang["messages_message"] = "សារ";
$lang["messages_message_placeholder"] = "សរសេរសាររបស់អ្នកនៅទីនេះ...";
$lang["messages_message_required"] = "តំរូវអោយមានសារ";
$lang["messages_multiple_phones"] = "(ក្នុងករណីមានបង្កាន់ដៃច្រើន, សូមបំពេញលេខទូរស័ព្ទដាច់ពីគ្នាដោយសញ្ញាក្បៀស)";
$lang["messages_phone"] = "លេខទូរស័ព្ទ";
$lang["messages_phone_number_required"] = "តំរូវអោយបំពេញលេខទូរស័ព្ទ";
$lang["messages_phone_placeholder"] = "បំពេញលេខទូរស័ព្ទនៅទីនេះ...";
$lang["messages_sms_send"] = "ផ្ញើរសារ";
$lang["messages_successfully_sent"] = "ការផ្ញើរសារបានជោគជ័យទៅកាន់: ";
$lang["messages_unsuccessfully_sent"] = "ការផ្ញើរសារមិនបានជោគជ័យទៅកាន់: ";
